using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public interface IDisplayBackground 
{
    void Display(int i, string path);
}
