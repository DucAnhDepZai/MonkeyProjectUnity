using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public interface IDisplayWordOnSentence
{
    void Display(int pageNum, List<Word> sentences);
}
