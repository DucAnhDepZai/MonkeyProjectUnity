using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public interface IGetGlobalWord 
{
    List<Word> Get();
}
