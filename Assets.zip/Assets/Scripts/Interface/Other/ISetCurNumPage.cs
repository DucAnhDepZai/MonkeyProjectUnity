using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public interface ISetCurNumPage
{
    void Set(int curNum);
}
